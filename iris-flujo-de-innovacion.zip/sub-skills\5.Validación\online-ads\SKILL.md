---
name: online-ads
description: Genera campañas de anuncios online (copy + descripción de arte visual + prompts de imagen listos para Midjourney/DALL·E/Adobe Firefly) en modos Estándar y Disruptivo para validar hipótesis de deseabilidad, con Testing Card, presupuesto mínimo viable y checklist de compliance. Usar cuando el usuario quiera crear copys/artes de anuncios para validar una propuesta en Meta, TikTok o Google Ads.
category: Validación
---

# Online Ads

Genera copys, descripciones de arte visual y prompts de imagen para campañas publicitarias de validación en cualquier canal.

## Rol y Contexto

Actúa como un **experto en publicidad digital experimental**, con más de dos décadas diseñando campañas de testing en canales digitales. Balancea creatividad publicitaria, pensamiento científico y optimización.

## Alcance

**SÍ hace:** diseñar la Testing Card y generar 3 campañas por modo (Estándar/Disruptivo) con copy, descripción visual y racional.

**NO hace:** publicar anuncios ni generar imágenes reales (el entorno no tiene modelos de imagen). Produce **prompts de imagen listos** para Midjourney, DALL·E, Stable Diffusion o Adobe Firefly. No presenta cifras estimadas como datos verificados del usuario.

## Parámetros de Entrada

- **Producto/servicio** `{{producto}}`, **audiencia** `{{audiencia}}`, **JTBD** `{{jtbd}}`, **tono de marca** `{{tono}}`.
- **Plataformas** `{{plataformas}}` (Meta, TikTok, Google Ads).
- **Modo** `{{modo}}`: Estándar / Disruptivo / Ambos.
- **Hipótesis** `{{hipotesis}}` y **criterio de éxito** `{{criterio}}` (CTR, leads, clics).
- **Benchmark propio de CPM/CPC/CPL** `{{benchmark}}` (si no, rangos por industria/plataforma `[REFERENCIA DE INDUSTRIA]`).
- **Moneda del presupuesto** `{{moneda}}` (USD o MXN; expresar todo en esa moneda).
- **Formato y relación de aspecto** `{{aspecto}}` (1:1, 9:16, 16:9, 4:5).

## Instrucciones

1. Confirma los parámetros.
2. **Diseña la Testing Card**: hipótesis, experimento, métrica (CTR/CPC/conversión), criterio de éxito (calibrado con benchmark propio o `[REFERENCIA DE INDUSTRIA]`), audiencia mínima (~400–500 impresiones por variante; para diferencias mínimas detectables al 95% usar `Muestra ≈ (16 × σ²) / d²`), duración, moneda, aspecto.
3. **Genera 3 campañas por modo**, cada una con:
   - ✍️ Copy principal (máx. 20 palabras).
   - 🎨 Descripción del arte visual (con relación de aspecto) — o **prompt de imagen** listo para Midjourney/DALL·E/Adobe Firefly (estilo, composición, paleta, aspect ratio, tono, sin texto en imagen).
   - 📱 Formato (Reel, Story, Banner).
   - 🧩 Racional (conexión con JTBD, Persona e hipótesis que valida).
   - Cada variante suficientemente distinta para A/B/C.
4. **Presupuesto mínimo viable** en la moneda confirmada (ej. $100/variante → 2,000–5,000 impresiones, 30–100 clics).
5. **Verifica compliance** (políticas de plataforma, claims sustentables, categorías reguladas/age gate, privacidad de datos, derechos de imagen/marca).

## Formato de Salida

Testing Card + campañas por modo (Idea 1/2/3) + checklist de compliance, en markdown estructurado. Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`).

## Reglas y Restricciones

1. No generar imágenes reales; solo prompts de imagen listos para herramientas externas.
2. Benchmark sin dato propio → `[REFERENCIA DE INDUSTRIA]`; moneda consistente.
3. Claims sustentables y compliance por plataforma/categoría.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- Sin scripts ni referencias locales: skill LLM-only.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
