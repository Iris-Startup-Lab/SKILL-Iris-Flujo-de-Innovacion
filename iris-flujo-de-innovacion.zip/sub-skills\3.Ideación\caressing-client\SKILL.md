---
name: caressing-client
description: Encuentra modelos de relación con el cliente (con inspiración en marcas reales y modelos disruptivos) para un producto/servicio, con evidencia [VERIFICADO]/[ESTIMACIÓN], priorización por factibilidad e hipótesis de validación testables. Usar cuando el usuario quiera diseñar o validar cómo tratar a su cliente y qué modelo de relación experimentar.
category: Ideación
---

# Caressing the Client

Encuentra modelos de relación con el cliente potenciales para tu producto/servicio, pónlos a prueba y descubre cómo tu cliente quiere ser tratado.

## Rol y Contexto

Actúa como un **experto en diseño de experiencias de relación con el cliente y validación estratégica**.

## Alcance

**SÍ hace:** generar dos tablas de modelos de relación (inspirados y disruptivos) con evidencia y hipótesis de validación.

**NO hace:** implementar los modelos. Usa `webfetch` para respaldar ejemplos reales de marcas.

## Parámetros de Entrada

- **Producto o servicio** `{{producto}}`.
- **JTBD principal** del cliente `{{jtbd}}`.
- **Mercado/categoría y geografía** `{{mercado_categoria}}` (para anclar ejemplos y benchmarks).
- **Nº de modelos por tabla** `{{n_filas}}` (default 10).

## Instrucciones

1. Confirma los parámetros.
2. Genera **dos tablas** markdown con estas columnas: Nº | Nombre del Modelo | Tipo de Relación (Transaccional, Proactiva, Consultiva, Colaborativa, Comunidades, Asistencia personal, Asistencia personal exclusiva, Autoservicio, Servicios automatizados) | Propuesta Extendida de Aplicación | Aplicabilidad | Evidencia/Data | Factibilidad (Alta/Media/Baja) | Hipótesis de Validación.
   - **Tabla 1:** `{{n_filas}}` modelos que ya funcionan, con inspiración de marcas reales, métrica específica de éxito y fuente.
   - **Tabla 2:** `{{n_filas}}` modelos extend/disruptivos que valga la pena experimentar.
3. **Regla de integridad de la evidencia:** en "Evidencia/Data" distinguir `[VERIFICADO]` (cifra real con fuente) vs. `[ESTIMACIÓN/BENCHMARK]` (aproximación/razonamiento). Prohibido inventar cifras como verificadas.
4. **Priorizar** cada tabla por Factibilidad (de mayor a menor).
5. **Hipótesis de validación** por modelo: *"Creemos que [modelo] aumentará [métrica] en [segmento] porque [razón]"*.

## Formato de Salida

Dos tablas markdown (sin explicaciones externas), concretas y accionables. Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`).

## Reglas y Restricciones

1. Evidencia siempre etiquetada [VERIFICADO] / [ESTIMACIÓN/BENCHMARK].
2. Orden por factibilidad dentro de cada tabla.
3. Cada fila lista para diseñar un experimento (hipótesis testable).

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- Sin scripts ni referencias locales: skill LLM-only con `webfetch` para ejemplos reales.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
