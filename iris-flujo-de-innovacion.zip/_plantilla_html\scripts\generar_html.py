"""
generar_html.py

Genera un reporte HTML interactivo con el diseño corporativo IRIS a partir de
un JSON estructurado (window.REPORT_DATA) y la plantilla base. Embebe el logo
oficial en base64 para que el HTML resultante sea 100% autocontenido (funciona
sin conexión y sin archivos externos, salvo Google Fonts y Chart.js por CDN).

Uso:
    python generar_html.py --data reporte.json -o reporte.html
    python generar_html.py --data reporte.json --logo assets/logo.png \
        --template templates/reporte_base.html -o reporte.html

Placeholders reemplazados en la plantilla:
    __REPORT_DATA__  -> objeto JSON del análisis
    __LOGO_BASE64__  -> data URI del logo (data:image/png;base64,...)
"""
import argparse
import base64
import json
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent          # _plantilla_html/scripts
_PLANTILLA_DIR = _HERE.parent / "templates"       # _plantilla_html/templates
_REPO_ROOT = _HERE.parents[1]                     # raíz del proyecto

LOGO_DEFAULT = _REPO_ROOT / "imagenes_iconos_etc" / "Logos_GS_Iris_transparent.png"
TEMPLATE_DEFAULT = _PLANTILLA_DIR / "reporte_base.html"


def logo_data_uri(logo_path):
    logo_path = Path(logo_path)
    if not logo_path.is_file():
        raise FileNotFoundError(f"Logo no encontrado: {logo_path}")
    data = logo_path.read_bytes()
    mime = "image/png" if logo_path.suffix.lower() == ".png" else "image/*"
    return f"data:{mime};base64," + base64.b64encode(data).decode("ascii")


def generar(data_path, output_path, template_path=None, logo_path=None):
    with open(data_path, encoding="utf-8") as f:
        data = json.load(f)

    template_path = Path(template_path) if template_path else TEMPLATE_DEFAULT
    logo_path = Path(logo_path) if logo_path else LOGO_DEFAULT

    with open(template_path, encoding="utf-8") as f:
        html = f.read()

    data_js = json.dumps(data, ensure_ascii=False, indent=2)
    uri = logo_data_uri(logo_path)

    if "__REPORT_DATA__" not in html:
        raise ValueError("La plantilla no contiene el placeholder __REPORT_DATA__")
    if "__LOGO_BASE64__" not in html:
        raise ValueError("La plantilla no contiene el placeholder __LOGO_BASE64__")

    html = html.replace("__REPORT_DATA__", data_js)
    html = html.replace("__LOGO_BASE64__", uri)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    size_kb = len(uri) // 1024
    print(f"Reporte generado: {output_path}")
    print(f"  datos: {data_path}")
    print(f"  logo embebido: {size_kb} KB (base64)")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description="Genera reporte HTML interactivo IRIS.")
    parser.add_argument("--data", required=True, help="JSON del análisis (window.REPORT_DATA)")
    parser.add_argument("--template", default=None, help="Plantilla HTML (default: reporte_base.html)")
    parser.add_argument("--logo", default=None, help="Ruta del logo PNG (default: logo oficial IRIS)")
    parser.add_argument("-o", "--output", default="reporte.html", help="Ruta de salida HTML")
    args = parser.parse_args(argv)

    try:
        return generar(args.data, args.output, args.template, args.logo)
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
