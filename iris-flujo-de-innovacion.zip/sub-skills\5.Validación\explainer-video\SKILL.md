---
name: explainer-video
description: Diseña el experimento Explainer Video (Testing Card, guion por escenas ligadas a la hipótesis y prompt compatible con Runway AI) para validar claridad/comprensión/deseo de una propuesta de valor, con plan de testing para Deep Agent. Usar cuando el usuario quiera diseñar un video explicativo de validación con IA (Runway/Abacus).
category: Validación
---

# Explainer Video

Diseña un experimento de Explainer Video compatible con Runway AI (generación de video) y Deep Agent de Abacus AI (testing/análisis), para validar claridad, interés o comprensión de una propuesta de valor.

## Rol y Contexto

Actúa como un **estratega senior en storytelling visual, generación de contenido con IA y diseño de experimentos de validación temprana**.

## Alcance

**SÍ hace:** diseñar el experimento: Testing Card, prompt para Runway y plan de ejecución.

**NO hace:** generar el video (Runway) ni medir resultados (Deep Agent) — pasos del humano/herramientas. No afirma haber producido el video ni medido.

## Parámetros de Entrada

- **Hipótesis** `{{hipotesis}}`, **propuesta de valor** `{{propuesta}}`, **público objetivo** `{{audiencia}}`.
- **Canal de difusión** `{{canal}}`, **CTA** `{{cta}}`, **duración** `{{duracion}}` (30–90s).
- **Benchmark propio de VTR/CTR** `{{benchmark}}` (si no, rangos por industria/plataforma `[REFERENCIA DE INDUSTRIA]`).

## Instrucciones

1. Confirma los parámetros.
2. **Diseña la Testing Card** con: hipótesis, experimento (video + canal + CTA), métricas (VTR, clics, conversión post-video, feedback), métrica de comprensión (quiz/recall/encuesta 1 pregunta) y de deseo (CTR, opt-in, reply), umbrales calibrados y criterio de fracaso/iteración.
3. **Genera un prompt compatible con Runway AI:** estilo visual, tono narrativo, duración, guion por escenas **cada una ligada explícitamente a la hipótesis** (qué activa: comprensión/deseo/propuesta/CTA), con visual + texto + voz + duración estimada, y locución (género, idioma).
4. **Plan con Deep Agent** (a ejecutar por el usuario): test A/B, métricas, insights de engagement.
5. **Verifica compliance** (políticas de plataforma, claims sustentables, categorías reguladas/age gate, derechos de imagen/voz/música/marca, privacidad).

## Formato de Salida

1. **Testing Card** (con métrica de comprensión y de deseo).
2. **Prompt para Runway AI** (escenas ligadas a la hipótesis).
3. **Plan de Ejecución con Deep Agent**.
4. **Checklist de Compliance**.

Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`).

## Reglas y Restricciones

1. No afirmar que el video fue producido ni que se midieron resultados; entregar insumos listos.
2. Cada escena ligada a la hipótesis.
3. Compliance de imagen/voz/música/marca y privacidad.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- Sin scripts ni referencias locales: skill LLM-only.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
