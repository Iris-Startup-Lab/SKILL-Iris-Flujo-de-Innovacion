# Plantilla de Salidas HTML Interactivas — IRIS

Infraestructura compartida para que cualquier skill del flujo de innovación IRIS genere su **salida principal como un reporte HTML interactivo** con el diseño corporativo oficial (logo + paleta morado/dorado, tipografías Sora/Inter), sin que cada skill tenga que escribir HTML a mano.

## Cómo funciona

Cada skill produce un **`reporte.json`** estructurado y luego ejecuta el generador:

```bash
python ../../_plantilla_html/scripts/generar_html.py \
    --data reporte.json -o reporte.html
```

El generador toma la plantilla `templates/reporte_base.html`, inyecta el JSON en `window.REPORT_DATA` y **embebe el logo oficial en base64**. El resultado es un `.html` autocontenido (funciona offline; solo requiere conexión para Google Fonts y Chart.js, que tienen fallback del sistema).

## Estructura

```
_plantilla_html/
├── templates/
│   └── reporte_base.html      # HTML interactivo genérico (header, toolbar, cards expandibles, charts, footer)
├── scripts/
│   ├── generar_html.py        # reporte.json + template + logo -> reporte.html
│   └── logo_base64.py         # helper: PNG -> data URI base64
└── README.md
```

- **Logo oficial:** `imagenes_iconos_etc/Logos_GS_Iris_transparent.png` (se resuelve automáticamente). Cada skill conserva además una copia en `assets/logo.png`.
- **Diseño oficial:** `Designs_files/Design_iris_main_colors.md` (paleta `--purple-*` / `--gold-*`, fuentes Sora/Inter).

## Esquema `REPORT_DATA`

```jsonc
{
  "meta": {
    "titulo": "Search Trend Analysis — Evidencia",
    "skill": "search-trend-analysis",
    "fase": "Investigación",
    "subtitulo": "Resumen de una línea del análisis",
    "resumen": "Resumen ejecutivo (2-3 líneas)",
    "fecha": "2026-08-12",
    "metodologia": "Opcional: texto para el modal de metodología"
  },
  "kpis": [
    { "label": "Keywords analizadas", "value": "12", "accent": false }
  ],
  "secciones": [
    {
      "titulo": "Evidencia por keyword",
      "items": [
        {
          "titulo": "huerto urbano",
          "subtitulo": "Interés promedio 38/100",
          "tags": ["primaria", "alta demanda"],
          "score": 23,                                  // opcional
          "veredicto": "perseverar",                     // perseverar | pivotear | descartar
          "body": [
            { "label": "Dato", "texto": "Interés relativo 0-100 con delta +12 en 12 meses." },
            { "label": "Interpretación", "texto": "Tendencia creciente sostenida." }
          ],
          "chart": {                                     // opcional
            "tipo": "line",                              // bar | horizontalBar | line | doughnut | pie
            "titulo": "Evolución del interés",
            "eje_x": "Mes", "eje_y": "Interés (0-100)",
            "labels": ["Ene","Feb","Mar"],
            "datasets": [ { "label": "huerto urbano", "data": [20,28,38] } ]
          },
          "fuentes": ["Google Trends (pytrends)"]
        }
      ]
    }
  ],
  "decisiones": [
    { "titulo": "Perseverar en 'huerto urbano'", "texto": "Supera el umbral...", "veredicto": "perseverar" }
  ],
  "advertencias": ["Datos estimados marcados con *"],
  "fuentes": ["Fuente 1", "Fuente 2"]
}
```

### Reglas del esquema

- `meta` y `secciones` son obligatorias; el resto es opcional.
- `veredicto` usa uno de: `perseverar` / `pivotear` / `descartar` (se renderiza con semáforo verde/ámbar/rojo).
- `chart.tipo` admite `bar`, `horizontalBar`, `line`, `doughnut`, `pie`.
- Todo texto del `body` se muestra con salto de línea preservado (`pre-wrap`).
- Los valores con cifras **estimadas** se marcan `*` o `[REFERENCIA DE INDUSTRIA]` según las reglas de integridad del flujo.

## Componentes interactivos (ya incluidos en la plantilla)

- Header hero con gradiente morado, mancha dorada y **logo oficial**.
- KPIs en el hero (stat cards translúcidas).
- Toolbar con **buscador en vivo**, **orden** (original / A–Z / score) y **chips de filtro** por veredicto y por tag.
- Tarjetas **expandibles inline** (una a la vez) con bloques de detalle y **gráficas Chart.js**.
- Sección de **Decisiones** con semáforo de veredicto.
- Secciones de **Advertencias** y **Fuentes**.
- Modal de **Metodología** (si `meta.metodologia` está definido).
- Accesibilidad: `aria-*`, foco visible dorado, `prefers-reduced-motion`, responsive.

## Verificación del HTML generado

Al generar, verificar que el archivo contiene:
1. `<!DOCTYPE html>` y las fuentes Sora/Inter.
2. `window.REPORT_DATA` con los datos.
3. El logo embebido como `data:image/png;base64,...`.
4. Los controles interactivos y la(s) gráfica(s) si `chart` está definido.
