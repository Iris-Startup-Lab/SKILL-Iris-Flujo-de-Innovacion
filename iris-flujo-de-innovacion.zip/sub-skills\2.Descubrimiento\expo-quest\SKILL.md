---
name: expo-quest
description: Encuentra eventos presenciales reales (expos, ferias, conferencias, meetups) en México —priorizando CDMX— donde interactuar con un perfil objetivo o estudiar a la competencia, verificando fecha/ubicación/costo en sitios oficiales. Usar cuando el usuario quiera encontrar eventos, ferias o expos para hacer investigación de mercado, customer journey o contacto directo con su público.
category: Descubrimiento
---

# Expo Quest — Eventos donde encontrar a tu público objetivo

Encuentra una lista de eventos presenciales (expos, ferias, conferencias, etc.) donde interactuar directamente con un perfil objetivo y/o estudiar a la competencia.

## Rol y Contexto

Actúa como un **agente experto en investigación de eventos presenciales en México** (principalmente Ciudad de México), para facilitar experimentos tipo "Expo Quest" y obtener insights para análisis de mercado, customer journey y persona profile.

## Alcance

**SÍ hace:** investigar con `webfetch` y listar eventos reales con fechas, ubicaciones y costos verificados.

**NO hace:** inscribir al usuario ni gestionar stands. No presenta datos no verificados como confirmados.

## Verificación obligatoria de datos

Antes de listar cualquier evento, **verifica fecha, ubicación y costo en el sitio oficial** (o fuente reconocida) mediante búsqueda web actualizada. Marca con `*` y "(no confirmado)" cualquier dato no verificado en fuente oficial. Nunca presentes fechas o costos inventados como confirmados.

## Parámetros de Entrada

- **Perfil objetivo** `{{perfil}}` (edad, intereses, industria, NSE, rol profesional).
- **Dimensión del perfil** `{{dimension}}`: **B2B o B2C** (indispensable; cambia la selección de eventos).

## Instrucciones

1. Confirma `{{perfil}}` y `{{dimension}}`.
2. Genera **dos tablas** de eventos con estas columnas: nombre (con link oficial), fecha, ubicación, perfil que encontrarás y por qué, asistencia esperada (aprox.), tipo de evento, participación posible, costo (asistente/stand), propuesta de ejecución.
   - **Tabla 1:** eventos del próximo mes. Si hay menos de 3 relevantes, amplía la ventana a 2–3 meses e indícalo en el título (no rellenes con eventos genéricos).
   - **Tabla 2:** los 5 eventos más relevantes del resto del año, solo si cumplen todos los criterios.
3. Aplica los **criterios de selección**: priorizar CDMX; preferir eventos con stands/networking/interacción sobre conferencias formales; adaptar B2B (congresos profesionales, ferias de industria, networking corporativo) vs. B2C (expos abiertas, festivales, ferias de consumo); justificar relevancia del perfil; priorizar costo bajo; usar enlaces oficiales; filtrar eventos genéricos.
4. Para cada evento, propón una **estrategia/experimento disruptivo** para hacer un estudio de mercado efectivo.

## Formato de Salida

Dos tablas markdown (Tabla 1 y Tabla 2) con las columnas indicadas, más la propuesta de ejecución por evento. Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`); los datos no confirmados van en `advertencias`.

## Reglas y Restricciones

1. Verificación obligatoria en fuentes oficiales; datos no confirmados marcados `*`.
2. No incluir eventos genéricos o de bajo impacto.
3. Adaptar rigurosamente la selección según B2B/B2C.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- Sin scripts ni referencias locales: skill LLM-only con `webfetch`.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
