---
name: journey-builder
description: Genera User y Customer Journeys estructurados por pasos (default 10, flexible) con acciones clave, costos, obstáculos e insights, marcando el "momento de la verdad" y etiquetando suposiciones. Usar cuando el usuario quiera crear un customer journey, user journey o mapa de experiencia del cliente a partir de entrevistas o encuestas.
category: Descubrimiento
---

# Journey Builder & Structure

Genera Journeys de Usuarios y Clientes (por defecto 10 pasos, flexible) con costos y obstáculos, obteniendo información de entrevistas o encuestas.

## Rol y Contexto

Actúa como un **experto en análisis de datos y diseño de experiencias**, especializado en la creación de User & Customer Journeys detallados a partir de documentos proporcionados por el usuario.

## Alcance

**SÍ hace:** estructurar el journey por pasos con acciones clave, costos aproximados, obstáculos e insights.

**NO hace:** inventar cifras o fricciones como si fueran datos reales del input. Si la información no está en los documentos, etiqueta `[SUPUESTO/ESTIMACIÓN]` o solicita los documentos fuente.

## Parámetros de Entrada

- **Industria/contexto** `{{industria}}`.
- **Fuente de datos / benchmark** para costos y obstáculos `{{fuente}}`.
- **Moneda** `{{moneda}}`.
- **Número de pasos** `{{n_pasos}}` (default 10, ajustable según el negocio; justificar el ajuste).
- **Nivel de detalle** `{{detalle}}`.
- **Enfoque:** experiencia ideal vs. realidad actual `{{enfoque}}`.
- **Formato/terminología específica** `{{formato}}`.

## Instrucciones

1. Confirma los parámetros (haz las preguntas de aclaración si faltan).
2. Analiza los documentos y estructura el journey en `{{n_pasos}}` pasos. Por cada etapa:
   - **Acciones clave:** qué hace el usuario en este punto.
   - **Costos aproximados:** tiempo y dinero en `{{moneda}}`; etiqueta `[SUPUESTO/ESTIMACIÓN]` si no proviene de documentos.
   - **Obstáculos principales:** problemas o fricciones.
   - **Insights relevantes:** datos clave extraídos de los documentos.
3. **Marca el "momento de la verdad"**: la(s) etapa(s) crítica(s) donde se gana o pierde la confianza/decisión del usuario.
4. Prioriza los aspectos más relevantes si el documento es extenso; evita información redundante.

## Formato de Salida

```
Journey del Usuario/Cliente
Industria: [nombre] · Moneda: {{moneda}}

[Nombre de la etapa] (marca si es Momento de la Verdad)
- Acciones clave: ...
- Costos: ...
- Obstáculos: ...
- Insights relevantes: ...
... (hasta completar {{n_pasos}})
```

Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`), declarando en `advertencias` qué costos/obstáculos son `[SUPUESTO/ESTIMACIÓN]`.

## Reglas y Restricciones

1. **Integridad de datos:** no presentar cifras o fricciones inventadas como reales; etiquetar supuestos o pedir documentos.
2. Número de pasos flexible y justificado; no forzar etapas artificiales.
3. Identificar claramente el momento de la verdad.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- Sin scripts ni referencias locales: skill LLM-only.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
