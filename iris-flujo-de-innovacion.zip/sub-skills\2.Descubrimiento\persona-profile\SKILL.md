---
name: persona-profile
description: Desarrolla protopersonas con atributos detallados integrando Job To Be Done (JTBD) con Momentos Vitales. Distingue entre protopersona hipotética (supuestos) y persona validada con datos reales. Usar cuando el usuario quiera crear perfiles de cliente/persona, protopersonas o buyer personas para estrategias y nuevos productos.
category: Descubrimiento
---

# Persona Profile

Desarrolla protopersonas con atributos detallados, integrando **Job To Be Done (JTBD)** con **Momentos Vitales** para estrategias y nuevos productos.

## Rol y Contexto

Actúa como un **analista experto en marketing y creación de perfiles de clientes** para un laboratorio de innovación corporativa. Marco teórico: *Value Proposition Design*, *Lean Customer Development*.

## Declaración de naturaleza del perfil (obligatoria)

Al inicio de cada entrega, indica explícitamente si se trata de:
- **Protopersona hipotética** (basada en supuestos y conocimiento general del mercado), o
- **Persona validada con datos** (respaldada por entrevistas, encuestas o investigación real aportada por el usuario).

Si **no se proporcionan insumos reales**, avísalo y marca cada afirmación no respaldada como **supuesto (\*)**. Nunca presentes datos inventados como reales.

## Parámetros de Entrada

- **Tipo de industria/mercado** `{{industria}}` (B2C, B2B, sector).
- **Objetivo principal del proyecto** `{{objetivo}}`.
- **Detalles geográficos/culturales** `{{geografia}}`.
- **Nivel de detalle deseado** `{{detalle}}`.
- **Número de personas** `{{n_personas}}` (1 primaria + opcionales secundarias; default 1 primaria).
- **Estilo de comunicación** `{{tono}}` (formal o cercano).
- **Formato de salida** `{{formato_salida}}`.
- **Integración con otras metodologías** `{{metodologias}}`.
- **Uso interno vs. externo** `{{uso}}`.
- **Insumos:** entrevistas de empatía, encuestas, investigación de competencia, info de mercado. Si falta alguno, indícalo y aclara qué partes son supuestos.

## Instrucciones

1. Recolecta y confirma los parámetros e insumos. Si faltan insumos reales, declara protopersona hipotética.
2. Genera el perfil incluyendo:
   - **Datos demográficos:** edad, género, ocupación, ubicación, NSE, ingresos.
   - **Adjetivos y rasgos de personalidad:** forma de ser, actitudes, estilo de vida, valores.
   - **Canales físicos y digitales:** dónde interactúa o es recurrente.
   - **Motivaciones y metas:** impulsores y objetivos a corto/largo plazo.
   - **Frustraciones o dolores:** obstáculos, problemas, temores.
   - **JTBD integrado con Momento Vital**, usando el formato:
     *"Cuando (situación en un momento vital), quiero (meta funcional) para (objetivo esperado) y que los demás vean (meta social) y así sentir que (meta emocional) sin (obstáculo más grande no resuelto)."*
     Considera Momentos Vitales personales, financieros, de consumo/hábito y culturales/sociales.
   - **Explicación de la relevancia del JTBD en el Customer Journey** y sus oportunidades estratégicas.
   - **Hobbies e intereses.**
   - **Frustraciones y motivaciones del día a día.**
   - **Frase común** típica del perfil.
   - **Marcas, influencers y creadores de contenido** que sigue.
   - **Breve biografía.**
3. Redacta conciso y coherente, 2–4 líneas por sección (salvo mayor profundidad pedida), formato homogéneo entre personas.

## Formato de Salida

Documento/presentación en el formato indicado, con declaración de naturaleza del perfil al inicio y cada sección claramente separada. Cuando haya varias personas, formato homogéneo y compacto para comparación.

Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`), indicando en `advertencias` qué campos son supuestos (`*`).

## Reglas y Restricciones

1. Declaración obligatoria de protopersona vs. persona validada.
2. Sin insumos reales, todo dato no respaldado lleva `*`.
3. No inventar datos demográficos/cuantitativos como si fueran verificados.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- Sin scripts ni referencias locales: skill LLM-only.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
