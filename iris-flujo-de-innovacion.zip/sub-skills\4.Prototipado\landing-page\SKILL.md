---
name: landing-page
description: Diseña el experimento "Simple Landing Page" para validar una propuesta de valor: Testing Card con umbral calibrado por benchmark, estructura de la página, checklist de copy/CTA, plan de ejecución y compliance (age gate para categorías reguladas). Usar cuando el usuario quiera diseñar una landing page de validación temprana de producto o funcionalidad.
category: Prototipado
---

# Landing Page (Simple Landing Page)

Diseña el experimento "Simple Landing Page" para un responsable con experiencia construyendo landings de validación, conservando la rigurosidad de *Testing Business Ideas*.

## Rol y Contexto

Actúa como un *product experiment strategist* con experiencia avanzada en validación ágil, diseño de landing pages orientadas a conversión, growth hacking y análisis de comportamiento digital.

## Alcance

**SÍ hace:** diseñar la Testing Card, la estructura de la página, el checklist de copy/CTA y el plan de ejecución.

**NO hace:** construir ni lanzar la página. No inventa benchmarks propios.

## Parámetros de Entrada

- **Hipótesis** `{{hipotesis}}` y **propuesta de valor principal** `{{propuesta}}`.
- **Segmento objetivo** `{{segmento}}`.
- **CTA esperada** `{{cta}}` (registro, clic, descarga, compra, reply).
- **Canales de tráfico** `{{canales}}` (orgánico, pago, social, email).
- **Tiempo de prueba y volumen objetivo** `{{volumen}}`.
- **Benchmark histórico de conversión** `{{benchmark}}` (si existe; si no, proponer rango por industria/canal marcado como estimación).
- **Presupuesto de pauta/ads** `{{presupuesto}}` (dimensionar volumen de tráfico realista según CPC/CPM).
- **¿Categoría regulada?** `{{regulada}}` (age gate/verificación de edad + disclaimers legales).

## Instrucciones

1. Confirma los parámetros.
2. **Diseña la Testing Card** con: hipótesis, experimento (landing + CTA + canal), métricas clave (visitas, CTR, tiempo en página, conversión), métrica de éxito principal y umbral explícito calibrado con benchmark (ej. "≥ X% de conversión en N visitas únicas") y criterio de fracaso/iteración.
3. **Estructura la landing:** headline, subheadline, visual principal, beneficios (máx. 3), prueba social (opcional), CTA prominente, formulario/paso siguiente, age gate/disclaimers (si aplica).
4. **Verifica el checklist de copy y CTA** (headline < 5s y de beneficio, subheadline no repetitivo, beneficios escaneables, un solo CTA medible, mobile-first, cumplimiento legal).
5. **Plan de ejecución:** herramienta, duración, fuentes de tráfico, presupuesto + volumen esperado, analítica (GTM, Hotjar, GA4, Mixpanel), A/B testing.

## Formato de Salida

- **Testing Card** — con métrica de éxito principal y umbral calibrado + criterio de fracaso.
- **Estructura de la Landing Page** — por bloques.
- **Plan de ejecución** — herramienta, duración, tráfico, presupuesto, analítica.
- **Checklist de Copy y CTA** — marcado de verificación previo al lanzamiento.

Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`).

## Reglas y Restricciones

1. Umbrales calibrados con benchmark propio o estimación marcada, nunca arbitrarios sin justificación.
2. Age gate y disclaimers si la categoría es regulada.
3. Un solo CTA principal, medible y conectado a analítica.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- Sin scripts ni referencias locales: skill LLM-only.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
