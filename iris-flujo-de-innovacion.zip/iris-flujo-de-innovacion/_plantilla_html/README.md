# Plantilla de Salidas HTML Interactivas — IRIS

Infraestructura compartida para que cualquier skill del flujo de innovación IRIS genere su **salida principal como un reporte HTML interactivo** con el diseño corporativo oficial (logo + paleta morado/dorado, tipografías Sora/Inter), sin que cada skill tenga que escribir HTML a mano.

## Cómo funciona

Cada skill produce un **`reporte.json`** estructurado y luego ejecuta el generador
**desde la raíz del repositorio** (la carpeta que contiene `pasos.json` y `sub-skills/`):

```bash
# como paso del flujo: el contexto del flujo se inyecta solo
python _plantilla_html/scripts/generar_html.py --data reporte.json \
    --estado flujo_estado.json --paso html_4 -o html_4.html

# skill suelta, fuera de un proyecto del flujo
python _plantilla_html/scripts/generar_html.py --data reporte.json \
    --sin-flujo -o reporte.html
```

El generador hace tres cosas antes de escribir el archivo:

1. **Inyecta el contexto del flujo** (con `--estado` y `--paso`): construye el bloque
   `flujo` desde `flujo_estado.json` + `pasos.json`. No lo escribas a mano.
2. **Valida el esquema** con `validar_report_data.py` y **falla si algo falta**, para que
   un reporte incompleto no se entregue como HTML en blanco.
3. **Embebe el logo oficial en base64**.

El resultado es un `.html` autocontenido para el contenido y el logo (embebido en
base64). Las fuentes y Chart.js se cargan por CDN: sin conexión las fuentes caen al
sistema y las gráficas muestran un aviso «no disponible sin conexión» en vez de romperse.

### Opciones

| Flag | Para qué |
| --- | --- |
| `--paso html_N` | Inyecta el contexto del flujo de ese paso |
| `--estado <ruta>` | `flujo_estado.json` (default: raíz del repo) |
| `--pasos <ruta>` | `pasos.json` (default: raíz del repo) |
| `--sin-flujo` | Skill suelta: no exige contexto del flujo |
| `--sin-historial` | No embeder los reportes de los pasos previos (HTML más pequeño, sin navegación interna entre pasos) |
| `--no-strict` | Salta la validación. **No lo uses para esquivar un error**: corrige el JSON |

Códigos de salida: `0` ok · `1` error de archivo/uso · `2` esquema o flujo inválido.

## Estructura

```
_plantilla_html/
├── templates/
│   ├── reporte_base.html         # v2: HTML interactivo genérico (ruta del flujo, índice,
│   │                             # contexto, cards expandibles, «Cómo se calculó», charts)
│   └── reporte_base_v1.html      # v1 (diseño anterior), para volver con --template
├── scripts/
│   ├── generar_html.py           # reporte.json + contexto + template + logo -> html
│   ├── validar_report_data.py    # valida el esquema REPORT_DATA (usable por separado)
│   └── logo_base64.py            # helper: PNG -> data URI base64
└── README.md
```

- **Logo oficial:** `imagenes_iconos_etc/Logos_GS_Iris_transparent.png` (se resuelve automáticamente). Cada skill conserva además una copia en `assets/logo.png`.
- **Diseño oficial:** `Designs_files/Design_iris_main_colors.md` (paleta `--purple-*` / `--gold-*`, fuentes Sora/Inter).

## Esquema `REPORT_DATA`

```jsonc
{
  "meta": {
    "titulo": "Search Trend Analysis — Evidencia",
    "skill": "search-trend-analysis",
    "fase": "Investigación",
    "subtitulo": "Resumen de una línea del análisis",
    "resumen": "Resumen ejecutivo (2-3 líneas)",
    "fecha": "2026-08-12",
    "metodologia": "Opcional: texto para el modal de metodología",
    "simulado": false,         // opcional: marca datos simulados en una skill suelta
    "origen_datos": {          // opcional: procedencia de los datos DE ESTE PASO
      "tipo": "reales",        // reales | simulados | mixtos
      "nota": "42 entrevistas reales de tres perfiles"
    }
  },
  "kpis": [
    { "label": "Keywords analizadas", "value": "12", "accent": false }
  ],
  "secciones": [
    {
      "titulo": "Evidencia por keyword",
      "items": [
        {
          "titulo": "huerto urbano",
          "subtitulo": "Interés promedio 38/100",
          "tags": ["primaria", "alta demanda"],
          "score": 23,                                  // opcional
          "veredicto": "perseverar",                     // perseverar | pivotear | descartar
          "significancia": {                             // opcional: lo escribe el SCRIPT de la prueba
            "estado": "significativo",                   // significativo | no_significativo | no_concluyente
            "lectura": "Supera el umbral, y la diferencia es demasiado grande para atribuirla a la casualidad."
          },
          "body": [
            { "label": "Dato", "texto": "Interés relativo 0-100 con delta +12 en 12 meses." },
            { "label": "Interpretación", "texto": "Tendencia creciente sostenida." }
          ],
          "estadistica": [                               // opcional: va a la ventana «Cómo se calculó»
            { "label": "Intervalo de confianza del 95%",
              "texto": "De 7.9% a 13.6% (± 2.8 puntos)…\n\nCómo se calcula: …\nFórmula: …" }
          ],
          "chart": {                                     // opcional
            "tipo": "line",                              // bar | horizontalBar | line | doughnut | pie
            "titulo": "Evolución del interés",
            "eje_x": "Mes", "eje_y": "Interés (0-100)",
            "labels": ["Ene","Feb","Mar"],
            "datasets": [ { "label": "huerto urbano", "data": [20,28,38] } ]
          },
          "tabla": {                                     // opcional: una tabla, o una lista
            "titulo": "Criterio → puntaje → justificación",
            "columnas": ["Criterio", "Puntaje", "Justificación"],
            "filas": [["Urgencia", "5/5", "6 de 6 entrevistados lo mencionan"],
                      ["TOTAL", "21/25", "PROTOTIPAR"]],
            "fila_total": true,                          // resalta la última fila
            "nota": "Cómo leer la tabla",
            "calculo": false                             // true = va a «Cómo se calculó», no a la vista
          },
          "fuentes": ["Google Trends (pytrends)"],
          "vista_previa": {                              // opcional: un HTML que el reporte abre en su ventana
            "archivo": "landing_demo.html",              // ruta relativa al reporte.json; el generador lo incrusta
            "titulo": "Landing de validación"
          },
          "persona": { },                                // opcional: ficha de persona
          "psf": { }                                     // opcional: análisis Problem-Solution Fit
        }
      ]
    }
  ],
  "decisiones": [
    { "titulo": "Perseverar en 'huerto urbano'", "texto": "Supera el umbral...", "veredicto": "perseverar" }
  ],
  "advertencias": ["Datos estimados marcados con *"],
  "fuentes": ["Fuente 1", "Fuente 2"]
}
```

### El bloque `tabla` (tabla genérica de un item)

Para el contenido que como párrafo se lee mal: la matriz criterio → puntaje → justificación de
un score, una proyección año a año, un desglose por buyer persona, un resultado por variante.
Se renderiza dentro del detalle de la tarjeta, con scroll horizontal propio si no cabe.

| Campo | Obligatorio | Qué es |
| --- | --- | --- |
| `columnas` | sí | Lista de encabezados |
| `filas` | sí | Lista de filas; cada fila es una lista de celdas **en el orden de `columnas`** |
| `titulo` | no | Encabezado de la tabla |
| `fila_total` | no | `true` resalta la última fila como TOTAL |
| `nota` | no | Cómo leer la tabla, debajo |

- `tabla` acepta **un objeto o una lista de objetos**: un item puede llevar varias tablas.
- **Una fila con menos celdas que columnas es error**, no aviso: la tabla saldría desalineada
  sin que el HTML se queje. Usa `""` en las celdas que no apliquen.
- Las celdas van con texto o números, nunca objetos ni listas.
- Las celdas numéricas se alinean solas con cifras tabulares (se detectan por su contenido).
- El buscador del reporte **mira dentro de las tablas**, así que una justificación escrita ahí
  es encontrable.

Existe por una fricción concreta del uso real: el score de una idea aparecía en la tarjeta y su
desglose criterio por criterio se quedaba en la conversación, así que el lector del HTML no
sabía de dónde salía el número. Los scripts del Dimensionador
(`calcular_score.py`, `calcular_modelo.py`, `calcular_tam_sam_som.py`) y
`analizar_resultados.py` de las skills de validación devuelven la sección con estas tablas ya
armadas, con `--seccion-reporte`.

El validador avisa (WARN, agregado, uno por reporte) si un item trae `score` y no trae ni una
tabla con columna «Justificación» ni un `body` con ese label: un puntaje sin decir de dónde sale.

### La estadística en tres capas: `significancia`, `estadistica` y «Cómo se calculó»

La persona que lee el reporte quiere saber **si el resultado es real o es azar**; la mayoría no
necesita ver cómo se calculó, pero tiene que poder verlo. Por eso la estadística se reparte en
tres capas, y ninguna se resume ni se suaviza: solo cambia de lugar.

| Capa | Dónde | Qué va |
| --- | --- | --- |
| 1. A la vista | Tarjeta y «En resumen» | La etiqueta de `significancia` con su `lectura` sin cifras, el veredicto, y en ámbar las fallas que cambian la decisión: datos simulados y el número de `advertencias` (que siguen completas, visibles, en su sección) |
| 2. Ventana «Cómo se calculó» | Botón en cada tarjeta y en la barra superior | `estadistica[]`, las tablas con `calculo: true`, los bloques de `body` con label de cálculo y `meta.metodologia` |
| 3. PDF / impresión | Al final del documento | Todo lo de la capa 2, completo, y los pasos anteriores desplegados |

**`significancia.estado`** — la etiqueta de la tarjeta:

| Estado | Se lee | Cuándo |
| --- | --- | --- |
| `significativo` | **Significativo** (verde) | La diferencia con el umbral, el control u otro segmento es demasiado grande para atribuirla al azar |
| `no_significativo` | **No significativo** (gris) | Con la muestra reunida no hay diferencia clara |
| `no_concluyente` | **Aún no se puede saber** (ámbar) | La muestra no alcanza para afirmar ni descartar, o no hay contra qué comparar |

- **El estado lo decide el script que hizo la prueba, nunca el modelo.**
  `analizar_resultados.py --seccion-reporte` lo escribe solo (`significancia()` traduce el
  veredicto que ya calculó). En los simuladores lo da la prueba z que imprime el script:
  `DIFERENCIA` → `significativo`; `sin diferencia` → `no_significativo`; segmento por debajo
  de 20 → `no_concluyente`.
- **`lectura` va sin cifras** y dice *de qué* es la significancia («Repartidores y uso
  personal responden distinto: la diferencia no es casualidad»). Las cifras van en `estadistica`.
- **`estadistica[]`** son bloques `{label, texto}` con lo que devolvió el script tal cual: la
  cifra exacta con su denominador e intervalo, la prueba, y la fórmula en sus dos versiones.
- **Compatibilidad:** un bloque de `body` cuyo label empieza por «Detalle estadístico», «Cómo
  se calculó», «Metodología» o «Fórmula» se trata como `estadistica`. Los reportes escritos
  antes de este campo pasan a la ventana sin reescribirlos.
- El validador avisa si un item trae `significancia` sin ningún cálculo detrás: una etiqueta
  que el lector no puede comprobar.
- **Con datos simulados** (marca del flujo o `meta.simulado`), la plantilla antepone «En la
  simulación:» a la lectura y explica en «En resumen» que «significativo» dice que la
  diferencia declarada en el plan se detectaría con esta muestra, no que exista en el mercado.

### Bloques especializados de item: `persona` y `psf`

Además de `body` y `chart`, un item puede llevar un bloque con estructura propia. La
plantilla lo renderiza con su layout (fichas, tablas adaptativas, matriz de cuadrantes) y
el validador comprueba su esquema:

| Bloque | Lo produce | Estructura vinculante |
| --- | --- | --- |
| `persona` | `persona-profile` (`html_4`) | `sub-skills/2.Descubrimiento/persona-profile/references/ficha-persona.md` |
| `psf` | `problem-solution-fit` (`html_5`) | `sub-skills/2.Descubrimiento/problem-solution-fit/references/analisis-psf.md` |

Dos reglas de render que valen para los dos:

- **Las tablas son adaptativas:** una columna solo aparece si al menos una fila trae ese
  dato. La ficha de persona sin evaluar (sin `solucion` / `costo` / `importancia` /
  `satisfaccion` en sus pains) imprime la tabla de dos columnas más una nota que remite a
  Problem-Solution Fit — ese análisis es el paso siguiente, así que la ficha **no** debe
  rellenar esas columnas con `[no disponible]` ni con cifras estimadas.
- **La matriz Importancia × Satisfacción se deriva**, nunca se escribe. La plantilla la
  arma con los pares `importancia` + `satisfaccion` de `persona.pains` o de
  `psf.problemas`; si no hay ningún par completo, no hay gráfica. Escribir un `chart` a
  mano duplicaría la fuente de verdad (y gana el `chart` explícito).

### El bloque `flujo` (contexto del flujo)

**No lo escribas a mano.** Lo inyecta el generador con `--estado` y `--paso`; se
documenta aquí solo para saber qué se renderiza:

```jsonc
{
  "flujo": {
    "proyecto": "Huertos urbanos MX",
    "objetivo_proyecto": "Validar demanda de kits de huerto",
    "audiencia": "Familias urbanas 28-45, CDMX",
    "paso_actual": "html_4",
    "paso_titulo": "Persona Profile",
    "paso_objetivo": "Convertir la evidencia en fichas de persona…",
    "paso_orden": 4,
    "total_pasos": 11,
    "avance": { "completados": 1, "omitidos": 1, "pendientes": 8 },
    "siguiente_paso": { "id": "html_5", "titulo": "Problem-Solution Fit",
                        "etapa": "Descubrimiento", "orden": 5, "objetivo": "…" },
    "ruta": [
      { "id": "html_1", "titulo": "Inicio + Investigación", "estado": "completado",
        "resumen": "TAM MX 4.2 mil M*…", "archivo": "html_1.html",
        "archivos": ["html_1.html", "benchmark.csv"], "datos": "reporte_h1.json",
        "veredicto": "perseverar" },
      { "id": "html_2", "titulo": "Decisión — Entrevistas", "estado": "omitido",
        "motivo": "Ya tiene 12 entrevistas hechas", "impacto": "persona-profile usa supuestos *" },
      { "id": "html_4", "titulo": "Persona Profile", "estado": "actual" }
    ],
    "decisiones": [
      { "paso": "html_1", "nodo": "¿Cómo quieres iniciar?", "opcion": "Estado actual",
        "opciones": ["Estado actual"] },
      { "paso": "html_3", "nodo": "Selección de agentes de descubrimiento",
        "opcion": "Encuesta Kano + Discovery Survey",
        "opciones": ["Encuesta Kano", "Discovery Survey"] }
    ],
    "omitidos": [{ "id": "html_2", "titulo": "…", "motivo": "…", "impacto": "…", "forzada": false }],
    "simulacion": { "activo": true, "desde": "html_2",
                    "nodo": "¿Ejecución de entrevistas?",
                    "opcion": "No — simulación de respuestas e insights",
                    "nota": "Las entrevistas y encuestas de este proyecto son SIMULADAS…" }
  }
}
```

Se renderiza como:

- **Riel de progreso** en el header: los 11 pasos con color por estado (completado en
  verde, omitido tachado, el actual en dorado). Los pasos ya completados **anteriores** al
  actual son botones que saltan a la sección embebida del historial (ver abajo, y la regla
  «Navegación interna sin `<a href>`»); si un paso completado no se pudo embeber
  (`--sin-historial`), ofrece el enlace al archivo vecino **solo cuando el reporte no está
  dentro de un iframe**, porque ahí no hay sistema de archivos que abrir.
- **Historial embebido** (bloque `flujo.historial`, lo rellena el generador): los reportes
  completos de los pasos anteriores viajan dentro del mismo HTML, uno por paso, en
  secciones plegables. Es lo que hace que el reporte sea navegable por sí mismo dentro de
  la pasarela de Claude / Codex, donde no hay sistema de archivos para abrir `html_2.html`.
  Cada entrada: `{id, titulo, etapa, orden, resumen, veredicto, reporte}` con el
  `reporte.json` completo. El tamaño crece de forma incremental (html_N embebe los N−1
  pasos previos), pero es despreciable: cada `reporte.json` pesa ~3–5 KB frente a los
  ~122 KB del logo embebido. Se desactiva con `--sin-historial`. Con el proyecto descargado,
  la cabecera de cada paso ofrece además **«Abrir el archivo»** (su `html_N.html` vecino, útil
  para ver dos pasos lado a lado o imprimir uno solo); dentro de la pasarela no se dibuja.
- **«De dónde viene este reporte»**: el proyecto, las decisiones tomadas, lo que ya se
  sabe de los pasos previos y —en caja ámbar— los pasos omitidos con su impacto, para que
  quien lea el reporte sepa qué le falta.
  - Cada decisión trae `opcion` (texto plano, varias unidas con ` + `) y `opciones` (la lista,
    en los nodos de elección múltiple). El bloque lo escribe `estado_flujo.py`, nunca la skill.
  - Si una decisión lleva `fuera_de_catalogo`, la opción **la propuso el agente** y no forma
    parte del catálogo del flujo: el reporte la marca «(propuesta del agente)». Es la única
    entrada del histórico que no salió de `pasos.json`, y por eso se distingue.
- **«En resumen»**: `meta.resumen` y la fila de veredictos al frente, antes del contexto,
  para que la conclusión se lea en los primeros segundos.
- **«Siguiente paso»** (`flujo.siguiente_paso`, lo calcula el generador): el cierre del
  reporte anuncia qué paso toca después.
- **Pie**: proyecto y posición en el flujo.
- **Marca de datos simulados** (si `simulacion.activo`): distintivo dorado «Datos simulados» en
  la cabecera, caja ámbar «esto no es evidencia de campo» como primer bloque del contexto,
  `DATOS SIMULADOS` en el pie, prefijo `SIMULADO ·` en el título de la pestaña y una
  advertencia automática si ninguna de las declaradas menciona la simulación. Lo enciende la
  decisión registrada en el flujo (opción marcada `marca_simulacion` en `pasos.json`), así que
  **ninguna skill tiene que acordarse de etiquetar**. Una skill que corre suelta, sin contexto
  de flujo, consigue lo mismo con `meta.simulado: true`. Convención completa:
  `sub-skills/SIMULACION.md`.
  - **`meta.origen_datos` matiza la marca sin apagarla.** La marca es del **proyecto**: en
    cuanto un paso simula, viaja a todos los reportes siguientes, y eso es lo correcto. Pero en
    el uso real un proyecto con 42 entrevistas **reales** que simuló solo las encuestas
    arrastraba la marca a los pasos 4–11, y en cada reporte había que escribir a mano «este paso
    está construido con entrevistas reales». Con
    `meta.origen_datos = {tipo: "reales"|"simulados"|"mixtos", nota: "…"}` esa aclaración se
    escribe sola, como una línea más de la caja ámbar: «Este paso en concreto está construido
    con datos reales de campo, no simulados — 42 entrevistas reales de tres perfiles». Solo se
    renderiza cuando hay simulación en el proyecto; el validador avisa si hay simulación y el
    reporte no declara su procedencia.

`estado` admite: `pendiente`, `en_curso`, `completado`, `omitido`, `fallido`, `actual`
(solo uno puede ser `actual`).

#### Navegación interna sin `<a href>` (obligatorio)

**Un salto dentro del reporte no se hace con un ancla.** La pasarela de Claude Desktop sirve
el HTML en un iframe propio (`claudeusercontent.com/?domain=claude.ai&parentOrigin=…`) e
intercepta el clic de **cualquier** `<a href>`: resuelve el href contra la URL de ese iframe
y lo trata como salida del producto. Un `href="#paso-1"` abría el diálogo *«Estás saliendo de
Claude para visitar un enlace externo»* con la URL del iframe en vez de saltar al paso. Con el
HTML descargado funcionaba; dentro de Claude, no.

Por eso el riel usa `<button>` y la lista «Lo que ya sabemos» un `<button class="salto">`, los
dos con `data-salto="N"`, y un único manejador delegado (`irAPaso`) abre el `<details>`, lo
desplaza con `scrollIntoView` —recalculando `scroll-margin-top` con la altura real de la barra
sticky, que si no tapa el título— y lo realza un segundo. No se pierde nada: el riel lo dibuja
el propio script, así que nunca hubo un caso «sin JavaScript» al que el ancla sirviera.

Al añadir navegación a la plantilla:

- **Dentro del documento** → `data-salto` + botón. Nunca `href="#…"`.
- **A otro archivo** → `<a href>` está bien, pero envuélvelo en la condición `!EMBEBIDO`
  (`window.self !== window.top`): dentro de la pasarela no hay archivo que abrir y el clic
  solo produce el diálogo. Así se dibujan el enlace del riel en modo `--sin-historial` y el
  botón «Abrir el archivo» de cada paso del historial.
- `EMBEBIDO` gobierna **solo** los enlaces a archivos. El salto interno funciona en los dos
  contextos sin consultarlo, así que el arreglo no depende de acertar la detección.

Tres campos de `ruta[]` son la **herencia entre pasos** —lo que la skill del paso siguiente
lee para no reconstruir el contexto desde cero:

| Campo | Qué es | Para qué |
| --- | --- | --- |
| `resumen` | Una línea: qué se aprendió | El índice. Se pinta en el riel y en «De dónde viene este reporte» |
| `datos` | Ruta del `reporte.json` de ese paso | **Los datos estructurados**: de aquí se heredan `persona`, `psf`, `secciones[].items[]` |
| `archivos` | Todos los outputs declarados | El resto de entregables (CSV, PPTX, HTML propios). `archivo` es el primero, el que enlaza el riel |

Los rellena `estado_flujo.py completar` con `--resumen`, `--datos` y `--outputs`.

### Reglas del esquema

- `meta` y `secciones` son obligatorias; el resto es opcional.
- `veredicto` usa uno de: `perseverar` / `pivotear` / `descartar` (se renderiza con semáforo verde/ámbar/rojo).
- `chart.tipo` admite `bar`, `horizontalBar`, `line`, `doughnut`, `pie`, `scatter`.
- `persona` y `psf` son opcionales y se validan con su esquema propio (ver arriba).
- Todo texto del `body` se muestra con salto de línea preservado (`pre-wrap`).
- Los valores con cifras **estimadas** se marcan `*` o `[REFERENCIA DE INDUSTRIA]` según las reglas de integridad del flujo.

## Componentes interactivos (ya incluidos en la plantilla)

Diseño v2 («Executive Hub») sobre la paleta oficial: página larga, superficies lavanda,
tarjetas blancas con borde fino, cápsulas de estado. **Sin Tailwind ni fuentes de iconos**:
el CSS vive en la plantilla y los iconos son SVG en línea, así que el reporte se ve igual sin
red y dentro del iframe de la pasarela de Claude.

- **Barra superior fija** con el logo oficial, «Paso N de 11 · título», proyecto, skill, el
  distintivo «Datos simulados» y los botones **Cómo se calculó** y **Exportar PDF**. En
  pantallas medianas oculta skill y proyecto (siguen en el pie y en «De dónde viene»); en
  móvil deja de ser fija.
- **Ruta del flujo** a todo el ancho: una ficha por paso con su estado (completado, este
  reporte, omitido, pendiente, falló).
- **Índice lateral** (en móvil, fila horizontal) con botones `data-ir`, nunca anclas.
- **KPIs** como tarjetas de métrica; `accent: true` la pinta en morado con cifra dorada.
- **«En resumen»** con veredictos, recuento de significancia y la franja ámbar de advertencias.
- Toolbar con **buscador en vivo**, **orden** (original / A–Z / score) y **chips de filtro** por veredicto y por tag.
- Tarjetas **expandibles inline** (una a la vez, también con teclado) con bloques de detalle y **gráficas Chart.js**.
- Sección de **Decisiones** con cápsula de veredicto.
- Secciones de **Advertencias** y **Fuentes**, siempre a la vista.
- Ventana **«Cómo se calculó»** (ver «La estadística en tres capas»).
- **«Ver la landing»** (`item.vista_previa`): el generador incrusta el HTML indicado (hasta
  8 MB) y la tarjeta abre una ventana ancha con la página en un iframe aislado (`sandbox`),
  con selector Escritorio / Móvil. Así la landing demo del paso 11 se revisa dentro del reporte,
  también en la pasarela de Claude. Si el archivo no está, el generador avisa y la tarjeta queda
  sin botón.
- **Impresión / PDF**: sin barra ni índice, pasos anteriores desplegados y el contenido de la
  ventana como anexo al final.
- Accesibilidad: `aria-*`, foco visible dorado, `prefers-reduced-motion`, responsive hasta 320 px.

**Volver al diseño anterior** no requiere tocar nada: la v1 se conserva en
`templates/reporte_base_v1.html` y se usa con `--template _plantilla_html/templates/reporte_base_v1.html`.
(La v1 no conoce `significancia` ni `estadistica`: los ignora y muestra `body` como siempre.)

## Guía para que el reporte se lea sin manual (base generalista)

La plantilla pone la forma; el autor pone el contenido. Un generalista —alguien que no
conoce el flujo— debe poder responder en 10 segundos **qué muestra este reporte**, **de
dónde viene** y **qué sigue**. Para eso, al escribir `reporte.json`:

- **`meta.resumen` (2–3 líneas)**: la conclusión. Es lo que alimenta el bloque «En
  resumen» del reporte. No es una descripción del método, es el «¿y entonces qué?».

  - Mal: «Se analizaron 10 competidores con las 5 Fuerzas de Porter».
  - Bien: «El nicho B2B SME es el hueco con mejor relación demanda/competencia: SOM
    proyectado $52M y solo dos jugadores directos.»

- **`meta.subtitulo` (1 línea)**: la bajada descriptiva del hero, complementaria al
  título. Si `resumen` ya dice todo, el subtítulo puede ser la descripción del método.

- **`kpis` (3–5 máximos)**: un número grande + `label` corto. Son el primer vistazo;
  no conviertas en KPI una cifra que no resuma el resultado.

- **`body` de cada item (2–4 bloques con `label` específico)**: evita un único bloque
  genérico tipo «Análisis: …». Prefiere etiquetas que respondan algo («Segmento»,
  «Modelo de ingresos», «Interpretación», «Riesgo»). La tarjeta expandida se lee por
  etiquetas.

- **`item.subtitulo` es la lectura, no el dato crudo.** Es lo único de la tarjeta que se
  ve sin abrir el detalle (junto a `tags`), así que va en una frase que un generalista
  entienda sin traducir notación. La cifra exacta —fracción, `%`, intervalo de confianza,
  p-valor— no desaparece: se declara completa (nunca redondeada ni suavizada) en
  `estadistica`, que el reporte muestra en la ventana «Cómo se calculó» (ver «La estadística
  en tres capas»). Si hubo una prueba, su resultado a la vista es `significancia`. Es el mismo
  principio que ya usan los scripts de validación (`analizar_resultados.py`): el valor lleva
  su `lectura` en palabras, y las dos versiones conviven — una a la vista, la otra a un clic.

  - Mal (`subtitulo`): «17/32 (53.1%, IC95 36.4%-69.1%)».
  - Bien (`subtitulo`): «Poco más de la mitad lo mencionó» — y en `estadistica`:
    `{"label": "Detalle estadístico", "texto": "17 de 32 (53.1%; IC95 de Wilson: 36.4%-69.1%)"}`.

  **`tags` son palabras, no códigos internos.** Un tag es para filtrar, y un generalista
  filtra por lo que entiende: «confirma la hipótesis», no `valida`; «dolor», no `pain`. Si
  un campo del JSON de origen usa un código en inglés o una abreviatura técnica, tradúcelo
  antes de escribirlo en `tags` — el campo del JSON no cambia, solo lo que se ve.

- **`veredicto`**: úsalo solo cuando hay una decisión respaldada. El reporte lo pinta con
  semáforo y lo explica al hover (perseverar = continuar · pivotear = ajustar ·
  descartar = abandonar). Sin veredicto, la tarjeta no lleva semáforo, y está bien.

- **`advertencias`**: declara aquí todo supuesto, cifra estimada (`*`) y ausencia
  (`[no disponible]`). El footer explica las marcas; las advertencias son donde se usan.

Checklist mínimo antes de dar por bueno un `reporte.json`: ¿tiene `resumen`? ¿los KPIs
resumen el resultado? ¿cada item se entiende por sus `body.label` sin abrir el detalle?
¿los supuestos están en `advertencias`? ¿el `subtitulo` y los `tags` de cada item se leen
sin saber estadística ni inglés, y la cifra exacta sigue completa en `estadistica`? ¿la
`significancia`, si la hay, salió del script y no de una estimación propia?

## Verificación del HTML generado

El generador ya valida el esquema y falla si algo falta. Si además quieres revisar el
archivo a mano, verifica que contenga:

1. `<!DOCTYPE html>` y las fuentes Sora/Inter.
2. `window.REPORT_DATA` con los datos y el bloque `flujo`.
3. El logo embebido como `data:image/png;base64,...`.
4. La ruta del flujo con el paso actual en morado con borde dorado y los omitidos tachados.
5. Los controles interactivos y la(s) gráfica(s) si `chart` está definido.
6. (Si hay pasos previos) la sección «Pasos anteriores del flujo» con un `<details>`
   por paso completado, y la ruta saltando a él con `data-salto` en vez de a archivos vecinos.
7. (Si hay `significancia` o `estadistica`) la etiqueta en la tarjeta y el botón «Cómo se
   calculó» abriendo la ventana; al imprimir, su contenido al final.

Para validar solo el JSON, sin generar HTML:

```bash
python _plantilla_html/scripts/validar_report_data.py reporte.json
```
