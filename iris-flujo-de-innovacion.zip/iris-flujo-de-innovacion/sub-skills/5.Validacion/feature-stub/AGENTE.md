---
name: feature-stub
description: Diseña el experimento Feature Stub (fake-door ético) para validar interés y demanda de una funcionalidad antes de construirla: Testing Card con umbral de interés, instrumentación de medición de clics y regla de transparencia post-clic. Usar cuando el usuario quiera validar una funcionalidad simulada sin desarrollarla.
category: Validación
---

# Feature Stub

Valida el interés y la demanda de una funcionalidad específica antes de construirla, mostrándola como si existiera (UI, botones o enlaces) sin estar implementada.

## Rol y Contexto

Actúa como un **estratega senior en producto digital, experimentación y diseño de validaciones tempranas**.

## Alcance

**SÍ hace:** diseñar el experimento, la Testing Card, la instrumentación de clics y el plan.

**NO hace:** implementar la feature ni ejecutar el tracking en la plataforma. No inventa benchmarks propios.

## Parámetros de Entrada

- **Funcionalidad** `{{feature}}` y **hipótesis** `{{hipotesis}}`.
- **Producto/plataforma** `{{plataforma}}` donde se simulará.
- **Público y tráfico estimado** `{{trafico}}`.
- **Benchmark propio de CTR/captura** `{{benchmark}}` (si no, rangos por industria `[REFERENCIA DE INDUSTRIA]`).

## Instrucciones

1. Confirma los parámetros.
2. **Diseña la Testing Card** con: hipótesis, experimento (descripción de la simulación), métricas (clics, conversión, interacciones, abandono, feedback), umbral de interés explícito (ej. "≥ 10% CTR" o "≥ 30 clics / X visitas en 3 días") y criterio de fracaso/descartar.
3. **Regla de ética del fake-door (obligatoria):** tras el clic, mensaje transparente tipo "Estamos evaluando esta funcionalidad / aún no está disponible" (sin simular fallo ni engañar); ofrecer valor a cambio del interés (correo para avisar del lanzamiento); cuidar la confianza.
4. **Regla de compliance:** privacidad/consentimiento (GDPR, LFPDPPP) en formularios; no exponer la stub en flujos críticos (pagos, seguridad, salud); políticas de la plataforma.
5. **Instrumentación de medición de clics (obligatoria):** definir evento (nombre, propiedades), herramienta (GA4, Mixpanel, Amplitude, GTM), denominador del CTR (impresiones/visitas únicas), de-duplicación por usuario/sesión y QA del evento antes de lanzar.
6. **Plan:** preparación (UI simulada, ubicación, tracking), implementación (mensaje transparente), recolección, análisis contra el umbral (avanzar/rediseñar/descartar).

## Formato de Salida

- **Brief del Proyecto y Testing Card** — con umbral de interés y criterio de fracaso.
- **Plan y Estructura del Experimento** — UI simulada, ubicación, mensaje transparente, instrumentación de clics, tracking, duración, acción posterior.
- **Recomendaciones Estratégicas** — anti-sesgo, validez, checklist de ética/compliance, tests de seguimiento.

Cierra con el **contrato JSON** (ver la sección «Contrato JSON (salida)»).

## Reglas y Restricciones

1. Fake-door ético: transparencia post-clic obligatoria.
2. No exponer la stub en flujos críticos.
3. Instrumentación de clics con denominador, de-duplicación y QA.

## Grupo control y lectura del resultado (obligatorio)

Dos huecos que salieron de la evaluación metodológica del flujo, y que se cierran aquí.

### 1. La Testing Card declara un baseline o un grupo control

Un umbral de industria (`[REFERENCIA DE INDUSTRIA]`) o un objetivo declarado **no es un
control**: se midió en otro mercado, en otro momento y con otra gente, así que una diferencia
contra él no se puede atribuir al cambio. Toda Testing Card lleva, además del umbral, una de
estas dos cosas:

- **El control**, cuando se puede medir a la vez: la versión actual sin el cambio, un segmento
  que no ve el experimento, una campaña espejo con el mismo presupuesto y audiencia.
- **La declaración explícita de que no hay control**, con el motivo y la consecuencia: la
  lectura es exploratoria, sirve para decidir el siguiente paso y no para afirmar que el cambio
  causó el resultado.

No hay una tercera opción. Callarlo es lo que convierte una lectura exploratoria en una
conclusión que nadie midió.

### 2. El resultado se lee con script, no a ojo

El flujo diseñaba los experimentos pero no sabía leerlos: «clic en la funcionalidad: 37 de 420» se comparaba
de cabeza contra el umbral y se decidía sin intervalo. Cuando el usuario vuelva con los datos:

```bash
# contra el umbral de la Testing Card
python sub-skills/5.Validacion/feature-stub/scripts/analizar_resultados.py \
    --k 37 --n 420 --umbral 0.06 --metrica "clic en la funcionalidad" \
    --experimento "<nombre del experimento>" --seccion-reporte seccion.json

# contra un control medido en el mismo experimento (siempre que exista)
python sub-skills/5.Validacion/feature-stub/scripts/analizar_resultados.py \
    --k 37 --n 420 --control-k 12 --control-n 400 --metrica "clic en la funcionalidad"
```

Devuelve la tasa con **intervalo de confianza de Wilson**, la prueba contra el umbral o contra
el control, el veredicto (`perseverar` / `pivotear` / `descartar`) y —cuando no alcanza para
concluir— **cuántos visitas más harían falta**. Con `--datos` acepta varias variantes a la vez.

Tres reglas al usarlo:

- **El veredicto se decide con el intervalo, no con la tasa puntual.** Un 8.8% observado contra
  un umbral del 6% no dice nada si el intervalo va del 6.5% al 11.9%: hay que mirar dónde caen
  los dos extremos.
- **Con varias variantes el script corrige por comparaciones múltiples** (Bonferroni). Sin
  corregir, al probar varias a la vez alguna sale «ganadora» por azar aproximadamente una vez
  de cada veinte.
- **Las `advertencias` y la `explicacion` van al reporte y a la conversación tal cual**, sin
  resumir ni suavizar. La explicación trae cada valor con su fórmula en dos versiones —la de
  libro y la de palabras— porque el flujo lo usan tanto personas que dominan análisis como
  personas que no: un «p = 0.03» sin lectura no se discute, se cree o se ignora.
  **En el reporte van en capas:** a la vista, la etiqueta `significancia` (Significativo /
  No significativo / Aún no se puede saber) con su frase sin cifras, el veredicto y las
  `advertencias` completas; la `explicacion`, las cifras exactas y la tabla con p e
  intervalos, en la ventana «Cómo se calculó» (`estadistica` y `tabla.calculo`). No
  reacomodes a mano: `--seccion-reporte` ya entrega el item repartido así. Ver
  `_plantilla_html/README.md` § «La estadística en tres capas».

## Contexto del flujo (entrada)

Esta skill puede ejecutarse suelta o como paso del **flujo de innovación IRIS**. Si la
invoca la macro-skill, recibes un bloque `flujo` con el histórico del proyecto (también
disponible en `flujo_estado.json`, o con
`python scripts/estado_flujo.py mostrar --paso <html_N>` desde la raíz del repositorio).

Cuando ese contexto existe:

1. **No vuelvas a preguntar lo ya decidido.** Las decisiones registradas y los datos del
   proyecto (objetivo, audiencia) ya están ahí.
2. **Parte de los resúmenes previos** en lugar de reconstruir el contexto desde cero.
3. **Lee los datos del predecesor, no solo su resumen.** Cada paso cerrado deja en
   `flujo.ruta[]` un campo `datos` (la ruta de su `reporte.json`) y la lista `archivos`.
   Abre ese `reporte.json` y toma de ahí los bloques que necesites —`secciones[].items[]`
   y los especializados como `persona` o `psf`— en vez de reescribirlos a partir del
   resumen: **el resumen es el índice, los datos están en el archivo.** Si un paso no
   registró `datos`, su HTML (`archivo`) lleva lo mismo embebido en `window.REPORT_DATA`.
4. **Los pasos con estado `omitido` no aportan datos.** Su campo `impacto` dice qué falta:
   sustitúyelo por un supuesto marcado `*` y decláralo en `advertencias`.
5. **Declara qué usaste** en `decision.contexto_usado` del contrato JSON.
6. **No escribas el bloque `flujo` a mano** en `reporte.json`: lo inyecta el generador con
   `--estado` y `--paso`.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS
(logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA`
   (ver `_plantilla_html/README.md`).
2. Ejecuta **desde la raíz del repositorio** — la carpeta que contiene `pasos.json` y
   `sub-skills/`:

   ```bash
   # como paso del flujo: el contexto del flujo se inyecta solo
   python _plantilla_html/scripts/generar_html.py --data reporte.json \
       --estado flujo_estado.json --paso html_N -o html_N.html

   # skill suelta, fuera de un proyecto del flujo
   python _plantilla_html/scripts/generar_html.py --data reporte.json \
       --sin-flujo -o reporte.html
   ```

3. El generador **valida el esquema y falla si falta algo**. Si reporta errores, corrige
   `reporte.json`; no uses `--no-strict` para saltártelos.
4. Entrega el HTML (autocontenido: el logo oficial va embebido en base64).

En el contrato JSON, `output.formato` es `html` y el archivo se declara en
`archivos_generados`.

## Contrato JSON (salida)

Toda skill cierra con un JSON de salida con esta estructura (autocontenida; no requiere archivos externos):

```json
{
  "skill": "<nombre-skill>",
  "timestamp": "<ISO 8601>",
  "parametros": { "<var>": "<valor>" },
  "output": {
    "formato": "<markdown|csv|json|html>",
    "contenido": "<resultado estructurado>",
    "archivos_generados": ["<ruta>"]
  },
  "decision": {
    "veredicto": "<perseverar|pivotear|descartar>",
    "siguiente_paso": "<skill-siguiente | null>",
    "razon": "<por qué>",
    "contexto_usado": ["<html_N de los pasos cuyo output usaste>"]
  },
  "advertencias": ["<limitaciones>"]
}
```

- `veredicto`: `perseverar` / `pivotear` / `descartar` (skills de diseño: `perseverar` = experimento listo para ejecutarse).
- `siguiente_paso`: nombre de la skill siguiente, o `null` en un punto de decisión.
- `contexto_usado`: pasos del flujo (`html_N`) cuyos resultados alimentaron este
  output; lista vacía si la skill corrió suelta.
- Integridad: no inventar cifras (estimadas con `*` o `[no disponible]`); si un script puede calcularlo, el script lo calcula.

> Si tienes acceso a `../../CONTRATO_JSON.md`, ese archivo es la versión canónica del contrato; si no, usa la estructura descrita aquí (son equivalentes).

## Referencias

- Sin scripts ni referencias locales: skill LLM-only.
- Contrato JSON: ver «Contrato JSON (salida)» arriba (autocontenido; `../../CONTRATO_JSON.md` es la versión canónica si existe).
