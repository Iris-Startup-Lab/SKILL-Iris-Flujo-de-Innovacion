# expo-quest

> Fase: 2.Descubrimiento

Encuentra eventos presenciales reales (expos, ferias, conferencias, meetups) en México —priorizando CDMX— donde interactuar con un perfil objetivo o estudiar a la competencia, verificando fecha/ubicación/costo en sitios oficiales. Usar cuando el usuario quiera encontrar eventos, ferias o expos para hacer investigación de mercado, customer journey o contacto directo con su público.

## Salida principal — HTML interactivo

Esta skill entrega su resultado como un **reporte HTML autocontenido** con el diseño corporativo IRIS (logo oficial + paleta morado/dorado, tipografías Sora/Inter).

### Generar el HTML

1. Estructura el resultado en `reporte.json` (esquema `REPORT_DATA` de `_plantilla_html/README.md`).
2. Ejecuta **desde la raíz del repositorio**:

   ```bash
   # como paso del flujo: el contexto del flujo se inyecta solo
   python _plantilla_html/scripts/generar_html.py --data reporte.json \
       --estado flujo_estado.json --paso html_N -o html_N.html

   # skill suelta
   python _plantilla_html/scripts/generar_html.py --data reporte.json --sin-flujo -o reporte.html
   ```

3. Entrega el HTML.

El logo se embebe en base64: el oficial del repositorio, o la copia `assets/logo.png` de
esta carpeta si la skill corre fuera del repo. Diseño de referencia:
`Designs_files/Design_iris_main_colors.md`.

## Simulación (sub-skill)

`simulador/` contiene un **simulador de interacciones** para cuando no se puede asistir al
evento: genera `expo_interacciones_SIMULADO.csv` (una fila por interacción × código, separando
asistentes de expositores) con muestreo reproducible por semilla, conteos y curva de saturación.
Esta skill consolida los hallazgos igual que con notas de campo reales.

```bash
python simulador/scripts/simular_expo.py plan.json -o expo_interacciones_SIMULADO.csv
```

Instrucciones: `simulador/SIMULADOR.md`. Convención: `sub-skills/SIMULACION.md`.

## Uso independiente

Esta skill es un paso del flujo IRIS, pero no depende de él para funcionar. Para usarla
sola basta con esta carpeta más `_plantilla_html/` al lado, y ejecutar el generador con
`--sin-flujo`: el contexto del flujo se omite y el logo sale de `assets/logo.png`.

Lo que aporta el repositorio completo —y que se pierde al extraerla— es el contexto del
flujo en el HTML (riel de progreso, decisiones previas, pasos omitidos) y el histórico de
`flujo_estado.json`. Nada de eso es necesario para producir el entregable.
