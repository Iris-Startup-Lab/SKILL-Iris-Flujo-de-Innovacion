# discovery-survey

> Fase: 2.Descubrimiento

Optimiza y mejora encuestas base ingresadas por el usuario (o diseñadas desde cero) para explorar Jobs, Pains y Gains, calculando tamaños de muestra estadísticamente significativos y estructurando Testing Cards profesionales.


Esta skill entrega su resultado como un **reporte HTML autocontenido** con el diseño corporativo IRIS (logo oficial + paleta morado/dorado, tipografías Sora/Inter).

### Generar el HTML

1. Estructura el resultado en `reporte.json` (esquema `REPORT_DATA` de `_plantilla_html/README.md`).
2. Ejecuta **desde la raíz del repositorio**:

   ```bash
   # como paso del flujo: el contexto del flujo se inyecta solo
   python _plantilla_html/scripts/generar_html.py --data reporte.json \
       --estado flujo_estado.json --paso html_N -o html_N.html

   # skill suelta
   python _plantilla_html/scripts/generar_html.py --data reporte.json --sin-flujo -o reporte.html
   ```

3. Entrega el HTML.

El logo se embebe en base64: el oficial del repositorio, o la copia `assets/logo.png` de
esta carpeta si la skill corre fuera del repo. Diseño de referencia:
`Designs_files/Design_iris_main_colors.md`.

## Simulación (sub-skill)

`simulador/` contiene un **simulador de respuestas** para cuando la encuesta no se puede
distribuir: genera `discovery_respuestas_SIMULADO.csv` en formato largo con muestreo
reproducible por semilla, proporciones con intervalo de Wilson, el `n` requerido para el margen
declarado y prueba z entre segmentos. Esta skill lo agrupa por afinidad igual que un export real.

```bash
python simulador/scripts/simular_discovery.py plan.json -o discovery_respuestas_SIMULADO.csv
```

Instrucciones: `simulador/SIMULADOR.md`. Convención: `sub-skills/SIMULACION.md`.

## Uso independiente

Esta skill es un paso del flujo IRIS, pero no depende de él para funcionar. Para usarla
sola basta con esta carpeta más `_plantilla_html/` al lado, y ejecutar el generador con
`--sin-flujo`: el contexto del flujo se omite y el logo sale de `assets/logo.png`.

Lo que aporta el repositorio completo —y que se pierde al extraerla— es el contexto del
flujo en el HTML (riel de progreso, decisiones previas, pasos omitidos) y el histórico de
`flujo_estado.json`. Nada de eso es necesario para producir el entregable.
