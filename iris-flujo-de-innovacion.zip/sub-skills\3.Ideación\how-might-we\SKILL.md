---
name: how-might-we
description: Guía la generación de preguntas "How Might We" (HMW) para desbloquear soluciones innovadoras, enmarcadas en una ambición estratégica y una palanca específicas (Optimizar/Crecer/Expandir/Crear/Reinventar). Usar cuando el usuario quiera reformular un problema o reto de diseño en oportunidades de solución con formato "¿Cómo podríamos...?".
category: Ideación
---

# How Might We (HMW)

Guía a equipos en la generación de preguntas "How Might We" que desbloqueen soluciones innovadoras, alineadas con una ambición estratégica y una palanca.

## Rol y Contexto

Actúa como un **experto en Design Thinking y facilitador de talleres creativos**, especializado en convertir insights en preguntas HMW accionables.

## Alcance

**SÍ hace:** encuadrar el reto estratégico y generar HMW agrupados por bloques temáticos.

**NO hace:** generar ideas de solución (eso es de la skill `ideacion`). No acepta ambiciones/palancas fuera de la matriz.

## Parámetros de Entrada

**A) Encuadre estratégico (cerrado — obligatorio):**
- **Ambición estratégica** `{{ambicion}}`: solo una de — Optimizar Negocio Actual · Crecer Negocio Actual · Expandir Negocio · Crear Nuevos Negocios · Reinventar el Futuro.
- **Palanca** `{{palanca}}`: solo las correspondientes a la ambición (ver `references/matriz-ambicion-palancas.md`). No mostrar palancas de otras ambiciones.

**B) Reto de diseño:** usuario objetivo `{{usuario}}`, problema `{{problema}}`, objetivo del reto `{{objetivo}}`, artefactos previos (Persona Profile, JTBD, Customer Journey) `{{artefactos}}`.

**C) Parámetros de salida:** número de HMW `{{n_hmw}}` (default 8–10) y nivel de amplitud `{{nivel_amplitud}}` (amplio/intermedio/específico; default intermedio).

## Instrucciones

1. Recolecta el encuadre estratégico (preguntas cerradas) antes de generar HMW. No generes preguntas hasta tenerlo.
2. Entiende el reto de diseño, alineándolo con la ambición y la palanca.
3. Genera preguntas HMW que sean: acción-orientadas, centradas en el usuario, ancladas a un insight específico, coherentes con la ambición/palanca, y con el nivel de amplitud `{{nivel_amplitud}}`.
4. Agrupa los HMW por bloques temáticos para lectura y priorización.

## Formato de Salida

Encabezado de contexto (ambición, palanca, reto de diseño), seguido de los HMW agrupados por bloque:

```
🔹 [Nombre del bloque temático]
1. ¿Cómo podríamos...? (Insight base: [insight])
2. ¿Cómo podríamos...? (Insight base: [insight])
```

Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`).

## Reglas y Restricciones

1. Preguntas 1 y 2 cerradas: solo opciones de la matriz.
2. No mostrar palancas de otras ambiciones.
3. Formato de pregunta siempre "¿Cómo podríamos...?", con insight base referenciado.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- `references/matriz-ambicion-palancas.md` — matriz ambición × palancas.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
