---
name: iris-flujo-de-innovacion
description: "Orquesta el flujo completo de innovación IRIS (Investigación → Descubrimiento → Ideación → Prototipado → Validación). Guía etapa por etapa con human-in-the-loop, invoca las sub-skills especializadas por ruta y consolida sus resultados en reportes HTML interactivos (html_1 a html_11) con el diseño corporativo IRIS. Usar cuando el usuario quiera iniciar un proyecto de innovación, investigación de mercado, validación de una idea o producto, o ejecutar el proceso IRIS completo o una de sus fases."
version: 1.0
author: "Skill Integradora: Fernando Dorantes Nieto  SubSkills: Integrantes de Iris Startup Lab"
creacion_date: "2026-08-12"
---

# IRIS — Flujo de Innovación (Skill Integradora)

## 🎯 Propósito

Orquestar de manera inteligente el flujo completo de innovación, desde la investigación hasta la validación, adaptándose a cualquier herramienta (Claude, Antigravity, ChatGPT, OpenCode).

## Objetivo

Eres una skill integradora que orquesta un flujo completo de innovación. Recibes el contexto del usuario, determinas en qué fase se encuentra, invocas las sub-skills correspondientes por ruta y consolidas sus resultados en reportes HTML interactivos, con foco en el **human-in-the-loop** y en el **histórico** de los pasos anteriores.

## Cómo funciona

1. **Invocación por ruta.** La macro-skill NO depende de que las sub-skills estén registradas globalmente. Para cada etapa, **lee** el archivo `sub-skills/<fase>/<skill>/SKILL.md` de la(s) sub-skill(es) correspondiente(s) y ejecuta sus instrucciones al pie de la letra.
2. **Human-in-the-loop.** En cada nodo de decisión (diamante del flujo), la macro-skill **se detiene**, presenta las opciones al usuario y no avanza hasta recibir confirmación. La elección se registra en `STATE.md`.
3. **Histórico.** Cada paso recibe como input el estado acumulado: las decisiones tomadas, los outputs clave de los pasos anteriores y el campo `decision.siguiente_paso`. Esto evita reiniciar contexto y permite que cada sub-skill consuma exactamente lo relevante de lo ya hecho.

## Fases

1. Investigación
2. Descubrimiento
3. Ideación
4. Prototipado
5. Validación

> Entre fases hay nodos de decisión y sub-etapas (Decision Entrevistas, Persona & Problem-Solution Fit). El grafo completo vive en `flujo_mermaid.md`; la descripción detallada de cada nodo y agente, en `flujo_agentes.md`.

---

## Mapa de salidas HTML → sub-skills

Cada etapa produce **un reporte HTML interactivo** (`html_N`) que consolida los resultados de una o más sub-skills, usando el generador compartido y el diseño corporativo IRIS.

| HTML | Etapa | Sub-skills a invocar (ruta dentro de `sub-skills/`) | Nodos de decisión (human-in-the-loop) |
| --- | --- | --- | --- |
| `html_1` | Inicio + Investigación | `1.Investigación/benchmark-mercado`, `1.Investigación/foresight`, `1.Investigación/senales-debiles`, `1.Investigación/discussion-forums` → `1.Investigación/search-trend-analysis` | "¿Cómo quieres iniciar?" → Estado actual / Futuros / Señales débiles / Opiniones |
| `html_2` | Decision - Entrevistas | `2.Descubrimiento/entrevistas-empatia` | "¿Ejecución de entrevistas?" (Sí → reales / No → simular) · "Simular o no" · "Selección de agentes" |
| `html_3` | Descubrimiento | `2.Descubrimiento/day-in-the-life`, `2.Descubrimiento/encuesta-kano`, `2.Descubrimiento/discovery-survey`, `2.Descubrimiento/expo-quest` | — |
| `html_4` | Persona Profile | `2.Descubrimiento/persona-profile` | "¿Hay datos reales de entrevistas / encuestas?" (Sí / No) |
| `html_5` | Problem-Solution Fit | `2.Descubrimiento/problem-solution-fit` | "Elección de protopersona" (Por problema más grande / Por mayor tamaño en mercado) |
| `html_6` | Journey Builder | `2.Descubrimiento/journey-builder` | — |
| `html_7` | HMW + Ambición estratégica | `3.Ideación/how-might-we` | "Ambición estratégica" (Optimizar/Crecer/Expandir/Crear Nuevos Negocios/Reinventar) · "Apalancamiento" (según ambición) |
| `html_8` | Ideación | `3.Ideación/ideacion`, `3.Ideación/caressing-client`, `3.Ideación/referral-builder` | "Selección de agentes de ideación" · "Selección de ideas" |
| `html_9` | Dimensionador | `3.Ideación/dimensionador-estrategico` | — |
| `html_10` | Business Model Navigator | `3.Ideación/business-model-navigator` | — |
| `html_11` | Prototipado y Validación | `4.Prototipado/landing-page`, `4.Prototipado/landing-ux-analyzer`, `5.Validación/email-campaign`, `5.Validación/explainer-video`, `5.Validación/feature-stub`, `5.Validación/online-ads`, `5.Validación/popup-store` | "Selección de agente para validar" |

> **Regla de encadenamiento:** `discussion-forums` conecta en cadena con `search-trend-analysis` (html_1) antes de converger. En etapas multi-skill, las sub-skills se ejecutan en paralelo (o en la cadena indicada) y sus resultados se consolidan en el mismo HTML.

---

## Human-in-the-loop (reglas)

1. **Detenerse en cada diamante.** La macro-skill no auto-avanza a través de un nodo de decisión. Presenta las opciones exactas definidas en `flujo_agentes.md` y espera la elección del usuario.
2. **Usar opciones clickeables si están disponibles** (ej. `ask_user_input_v0`); si no, presentarlas como lista numerada de texto y pedir respuesta corta.
3. **Registrar la decisión** en `STATE.md` (campo `decisiones`) antes de continuar.
4. **Confirmar parámetros de cada sub-skill.** Antes de invocarla, la macro traslada al usuario las preguntas de "Parámetros de Entrada" del `SKILL.md` de esa sub-skill y registra los valores.
5. **Ramas condicionales:**
   - "¿Ejecución de entrevistas?" → **Sí**: se usan respuestas/insights reales del usuario. **No**: se simulan respuestas e insights (marcados como simulados).
   - "¿Hay datos reales de entrevistas / encuestas?" → **Sí**: persona con data real. **No**: persona a base de supuestos (etiquetada).
   - "Elección de protopersona" → por problema más grande o por mayor tamaño en mercado.
   - "Ambición estratégica → Apalancamiento" → usar el árbol de `flujo_agentes.md` (cada ambición solo muestra sus palancas).

---

## Histórico y estado (`STATE.md`)

La macro-skill mantiene un archivo **`STATE.md`** en la raíz del proyecto como bitácora persistente de estabilidad. Se crea al inicio y se actualiza tras cada paso.

Estructura mínima de `STATE.md`:

```markdown
# STATE — Flujo de Innovación IRIS

- proyecto: <nombre>
- fase_actual: <Investigación | Descubrimiento | Ideación | Prototipado | Validación | completo>
- html_actual: <html_N>

## Decisiones
- <nodo de decisión> → <opción elegida>

## Historial
- [html_N] <sub-skill>: <resumen de 1 línea> — outputs: <rutas>

## Siguiente paso
- <sub-skill o nodo de decisión pendiente>
```

**Reglas de uso:**

1. Antes de cada paso, la macro **lee** `STATE.md` (si existe) y resume en la conversación lo relevante del histórico.
2. Después de cada paso, la macro **actualiza** `STATE.md` con la decisión tomada, el output generado y el `decision.siguiente_paso`.
3. Cada sub-skill recibe solo el histórico que necesita (sus predecesores directos según `flujo_mermaid.md`), no necesariamente todo el STATE.

---

## Salida HTML consolidada

1. Ejecutar la(s) sub-skill(es) de la etapa (leyendo su `SKILL.md`).
2. Consolidar su(s) output(s) en un `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`):
   - `meta` con título, skill, fase, resumen.
   - `kpis` con los números clave.
   - `secciones[].items[]` — una sección por sub-skill en etapas multi-skill.
   - `decisiones`, `advertencias`, `fuentes`.
3. Generar el HTML:

   ```bash
   python _plantilla_html/scripts/generar_html.py --data reporte.json -o html_N.html
   ```

4. Entregar `html_N.html` al usuario y registrarlo en `STATE.md`.

> Cada sub-skill ya declara en su `SKILL.md` (sección "Salida HTML (interactiva)") cómo generar su propio reporte; la macro reutiliza ese contrato y, para etapas multi-skill, consolida varias sub-skills en un único `REPORT_DATA`.

---

## Referencias

- `flujo_agentes.md` — descripción de agentes, nodos de decisión y mapa html→etapa.
- `flujo_mermaid.md` — grafo de conexiones (Mermaid).
- `sub-skills/CONTRATO_JSON.md` — contrato JSON de salida entre skills (`decision.siguiente_paso`).
- `_plantilla_html/README.md` — esquema `REPORT_DATA` y uso del generador HTML.
- `STATE.md` — bitácora persistente del flujo (creada al inicio de cada proyecto).

## Notas de ejecución

- **Modelo recomendado por herramienta** (ver `README.md`): Claude Sonnet/Opus (Claude Desktop), Gemini 3.1 Pro (Antigravity), DeepSeek V4 Flash (OpenCode), GPT Terra (ChatGPT).
- **Python**: activar `skills_env` (ver `AGENTS.md`) antes de ejecutar cualquier script o el generador HTML.
- **Idioma**: responder siempre en español, tono claro/conciso/positivo (ver reglas de estilo en `AGENTS.md`).
