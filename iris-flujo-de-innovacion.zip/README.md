# IRIS — Innovation Research & Intelligence System

Repositorio del **flujo de innovación IRIS** (Iris StartUp Lab). Contiene una **macro-skill orquestadora** (`iris-flujo-de-innovacion`) que guía al usuario por el flujo completo de innovación —de la investigación a la validación— invocando **26 sub-skills** especializadas y consolidando sus resultados en **reportes HTML interactivos** con el diseño corporativo IRIS.

## Qué contiene

| Elemento | Descripción |
|---|---|
| `SKILL.md` | Macro-skill orquestadora (nombre `iris-flujo-de-innovacion`). |
| `flujo_agentes.md` / `flujo_mermaid.md` | Fuente de verdad del flujo: agentes, decisiones y mapa `html_1 … html_11 → etapa`. |
| `STATE.md` | Bitácora persistente del flujo (creada/actualizada por la macro-skill). |
| `sub-skills/` | Las 26 sub-skills, organizadas por fase. |
| `_plantilla_html/` | Generador + plantilla HTML compartidos (salida interactiva con diseño IRIS). |
| `sub-skills_sample_outputs/` | Muestras de salida HTML por skill (para revisar el diseño). |
| `Documentos_prompts_base_md/` | Los 24 prompts originales (fuente de cada skill). |

## Fases del flujo

1. **Investigación** — benchmark-mercado, foresight, senales-debiles, discussion-forums, search-trend-analysis.
2. **Descubrimiento** — entrevistas-empatia, day-in-the-life, encuesta-kano, discovery-survey, expo-quest, persona-profile, problem-solution-fit, journey-builder.
3. **Ideación** — how-might-we, ideacion, caressing-client, referral-builder, dimensionador-estrategico, business-model-navigator.
4. **Prototipado** — landing-page, landing-ux-analyzer.
5. **Validación** — email-campaign, explainer-video, feature-stub, online-ads, popup-store.

## Tutorial de uso

### Cómo iniciar un proyecto

1. El usuario indica que desea iniciar un nuevo proyecto.
2. El usuario indica el nombre del proyecto.
3. El usuario indica el objetivo del proyecto.
4. El usuario indica la audiencia del proyecto.
5. El usuario indica los insumos del proyecto.
6. El usuario indica las herramientas que desea utilizar.
7. El usuario indica el formato de salida.
8. El usuario indica las restricciones.
9. El usuario indica las referencias.

La macro-skill arranca con el nodo de decisión **"¿Cómo quieres iniciar?"** (Estado actual → Benchmark · Futuros → Foresight · Señales débiles → Señales débiles · Opiniones → Discussion Forums) y avanza etapa por etapa con **human-in-the-loop**, deteniéndose en cada decisión y registrando todo en `STATE.md`.

### Modelo recomendado por herramienta

| Herramienta | Recomendado | Alternativa |
|---|---|---|
| **Claude Desktop** | Claude Sonnet | Claude Opus (más gasto) |
| **Antigravity** | Gemini 3.1 Pro | — |
| **OpenCode** | DeepSeek V4 Flash | — |
| **ChatGPT Desktop** | GPT Terra | — |

## Salidas HTML (diseño IRIS)

Cada skill entrega su resultado como un **reporte HTML interactivo** autocontenido (logo embebido en base64, tipografías Sora/Inter, paleta morado/dorado). Para generarlo:

```bash
python _plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
```

- Esquema del JSON (`REPORT_DATA`) y guía: `_plantilla_html/README.md`.
- Diseño oficial: `Designs_files/Design_iris_main_colors.md`.
- Logo oficial: `imagenes_iconos_etc/Logos_GS_Iris_transparent.png`.
- Ejemplos visuales: `sub-skills_sample_outputs/`.

## Empaquetado de la skill (ZIP)

Los gestores de agentes suelen tener un límite de **30 MB** por skill. El paquete con los documentos necesarios pesa ~3 MB (muy por debajo del límite). Para generarlo:

**PowerShell (Windows):**

```powershell
.\empaquetar_skill.ps1                              # ZIP básico (~3 MB)
.\empaquetar_skill.ps1 -IncludeSamples              # + muestras de diseño
.\empaquetar_skill.ps1 -IncludeFlujoMap             # + mapa visual (Flujo Agentes mapa 2.html, ~7.3 MB)
.\empaquetar_skill.ps1 -Output "mi_skill.zip"       # nombre personalizado
```

**Bash (Linux/macOS):**

```bash
./empaquetar_skill.sh                               # ZIP básico
./empaquetar_skill.sh --samples --flujo             # opciones adicionales
./empaquetar_skill.sh -o mi_skill.zip               # nombre personalizado
```

Opciones: `-IncludeSamples`/`--samples` (muestras), `-IncludeFlujoMap`/`--flujo` (mapa visual), `-IncludeDocx`/`--docx` (prompts .docx), `-IncludeTemp`/`--temp` (screenshots).

**Qué se incluye por defecto:** `SKILL.md`, `STATE.md`, `AGENTS.md`, `README.md`, `flujo_agentes.md`, `flujo_mermaid.md`, `sub-skills/`, `_plantilla_html/`, `Designs_files/`, `imagenes_iconos_etc/`, `Documentos_prompts_base_md/`. **Se excluyen:** `__pycache__`/`*.pyc`, el mapa visual grande, notebooks y archivos de desarrollo.
