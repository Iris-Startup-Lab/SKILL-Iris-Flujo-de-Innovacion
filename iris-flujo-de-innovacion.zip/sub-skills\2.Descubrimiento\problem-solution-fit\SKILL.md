---
name: problem-solution-fit
description: Genera un análisis estructurado de Problem-Solution Fit a partir de entrevistas o encuestas: identifica problemas clave, evalúa importancia, satisfacción con la solución actual y costos, valida la solución propuesta y extrae insights JTBD y Blue Ocean, exportando a CSV. Usar cuando el usuario tenga entrevistas/encuestas y quiera evaluar si su solución encaja con los problemas del cliente.
category: Descubrimiento
---

# Problem-Solution Fit

Genera un análisis estructurado de Problem-Solution Fit a partir de entrevistas o encuestas, identificando problemas clave, evaluando la solución y extrayendo insights accionables (JTBD + Blue Ocean Strategy).

## Rol y Contexto

Actúa como un **experto en análisis de Problem-Solution Fit**, con conocimiento en Lean Startup, Design Thinking, Jobs To Be Done (JTBD) y Blue Ocean Strategy. Marco teórico: *Value Proposition Design*, *Lean Customer Development*.

## Alcance

**SÍ hace:** analizar respuestas reales de entrevistas/encuestas para identificar problemas, evaluar importancia y satisfacción, medir costos, validar la solución y exportar a CSV.

**NO hace:** inventar cifras. Los costos deben derivarse de citas explícitas del input. Sin datos reales, no ejecuta análisis como si fuera real.

## Parámetros de Entrada

- **Respuestas de entrevistas/encuestas** (texto o tabla estructurada).
- **Número de entrevistas / tamaño de muestra** `{{n_muestra}}` para ponderar la columna de Frecuencia (Alta/Media/Baja o conteo). Si no se conoce, sugiere un tamaño según contexto, marcado `*`.

## Instrucciones

1. Confirma `{{n_muestra}}` y la disponibilidad de datos reales.
2. Analiza las respuestas para:
   - **Identificar problemas clave** (más mencionados, contexto e impacto).
   - **Evaluar importancia** (1–5 según impacto en la actividad del usuario).
   - **Analizar satisfacción con la solución actual** (1–5).
   - **Medir costos:** tiempo (horas/semana) y dinero (USD/mes), **solo a partir de citas explícitas**.
   - **Validar la solución propuesta** (Sí/No/Parcialmente) y sugerir ajustes.
   - **Extraer patrones y tendencias** (similitudes/divergencias).
   - **JTBD:** ¿qué "trabajo" intenta resolver el usuario y cómo mejorarlo?
   - **Blue Ocean:** oportunidades de diferenciación y propuesta de valor única.
3. Estructura el resultado y **exporta a CSV:**
   ```bash
   python scripts/exportar_csv.py analisis.json -o problem_solution_fit.csv
   ```
   (Escribe primero el `analisis.json` con la lista de problemas y sus campos; ver `scripts/exportar_csv.py` para el esquema de columnas.)

## Formato de Salida

- **Análisis en markdown** (problemas priorizados, evaluación de solución, JTBD, Blue Ocean, recomendaciones).
- **CSV** (`problem_solution_fit.csv`) con columnas: problema, contexto, impacto (1-5), satisfacción solución actual (1-5), costo tiempo (hrs/sem), costo dinero (USD/mes), solución cubre (Sí/No/Parcial), ajustes, patrones, JTBD, oportunidad Blue Ocean.

Cierra con el **contrato JSON** (ver `../../CONTRATO_JSON.md`), declarando el CSV en `archivos_generados`.

## Reglas y Restricciones

1. **Integridad de datos (obligatoria):** costo en tiempo/dinero solo de citas explícitas; si se infiere, marcar `[ESTIMACIÓN]`; si no hay mención, `N/D`. Prohibido inventar cifras.
2. Si no se proporcionan datos reales: solicitar los datos, o etiquetar toda la salida como **"DATOS SIMULADOS"** si el usuario pide un ejemplo.
3. Priorizar problemas más recurrentes y de mayor impacto; señalar inconsistencias entre impacto y costos.

## Salida HTML (interactiva)

La salida principal es un **reporte HTML interactivo** con el diseño corporativo IRIS (logo + paleta morado/dorado). Para generarlo:

1. Estructura el resultado en `reporte.json` según el esquema `REPORT_DATA` (ver `_plantilla_html/README.md`).
2. Ejecuta:
   ```bash
   python ../../../_plantilla_html/scripts/generar_html.py --data reporte.json -o reporte.html
   ```
3. Entrega `reporte.html` (autocontenido; el logo oficial se embebe en base64).

En el contrato JSON, `output.formato` es `html` y `reporte.html` se declara en `archivos_generados`.

## Referencias

- `scripts/exportar_csv.py` — exporta el análisis a CSV estructurado.
- `../../CONTRATO_JSON.md` — contrato de salida estándar entre skills.
