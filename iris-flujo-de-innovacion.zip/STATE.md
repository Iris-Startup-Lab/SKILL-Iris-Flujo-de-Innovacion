# STATE — Flujo de Innovación IRIS

> Bitácora persistente del flujo. La macro-skill `iris-flujo-de-innovacion` la crea al iniciar un proyecto y la actualiza tras cada paso. No borrar entre pasos: es la memoria del flujo.

- proyecto: (sin iniciar)
- fase_actual: (sin iniciar)
- html_actual: (ninguno)

## Decisiones

_(registro de cada nodo de decisión → opción elegida)_

## Historial

_(un bloque por paso: [html_N] sub-skill → resumen + rutas de outputs)_

## Siguiente paso

_(sub-skill o nodo de decisión pendiente)_
